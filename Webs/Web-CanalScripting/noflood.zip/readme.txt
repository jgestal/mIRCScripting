;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;; BaT No Flood! 1.0
;; BAT (BravoS AssAulT TeaM)     
;;
;; Coded by Jimmy_RAY
;;
;; http://www.gra2.com/jimmyray
;; http://www.gra2.com/scripting
;;
;; mail: jimmy@welt.es 
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

	Unzip all files in mIRC directory and load "loadme.mrc"
writing this mIRC command: /load -rs loadme.mrc

	More scripts and addOns in www.gra2.com/scripting and www.gra2.com/jimmyray