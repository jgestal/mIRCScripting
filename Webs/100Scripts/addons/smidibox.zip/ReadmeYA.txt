******************************************
*         MidiBox 1.0 por Garic          *
*     �1998 Garic puypat@globalnet.es    *
******************************************
Instalacion:
/load -rs midibox.ini
Y ya esta!!!