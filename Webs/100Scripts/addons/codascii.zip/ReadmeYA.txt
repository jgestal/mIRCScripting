 Ascii Window
--------------
En realidad este addon es una parte de mi script pero he decidido que 
aquellos que lo quieran utilizar lo pongan libremente en su script.
De momento esta es la unica parte de mi script que es libre de usar en 
cualquier otro, si encontrais algo que os guste de mi script para el vuestro
por favor, preguntadme primero si podeis usarlo.

Instalacion y uso?
pos cargalo y escribe /ascii

�1999 por ^GaRiC^